Thanks for contributing! Please see the
__Contributor Guide__ section in [the documentation](https://jupyter-docker-stacks.readthedocs.io) for
information about how to contribute
[package updates](http://jupyter-docker-stacks.readthedocs.io/en/latest/contributing/packages.html),
[recipes](http://jupyter-docker-stacks.readthedocs.io/en/latest/contributing/recipes.html),
[tests](http://jupyter-docker-stacks.readthedocs.io/en/latest/contributing/tests.html),
[features](http://jupyter-docker-stacks.readthedocs.io/en/latest/contributing/features.html),
[translations](https://jupyter-docker-stacks.readthedocs.io/en/latest/contributing/translations.html),
and
[community-maintained stacks](http://jupyter-docker-stacks.readthedocs.io/en/latest/contributing/stacks.html).
